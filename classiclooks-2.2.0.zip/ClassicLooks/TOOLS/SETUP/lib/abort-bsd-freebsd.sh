#!/bin/bash

echo "FAIL"
echo "----"
echo "Cannot run setup from this location."
echo "You can run setup only from an existing installation for your own user, from '$themes_dir_user/ClassicLooks/TOOLS/SETUP/'."
source ./lib/abort-common.sh
