#!/bin/bash

echo
echo "Setup aborted, press <ENTER> to close this window."
read -s
echo
exit
